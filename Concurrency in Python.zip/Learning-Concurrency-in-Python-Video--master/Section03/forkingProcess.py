import time
from multiprocess import multiprocess

def MyProcess():
  print("My Process Starting")
  time.sleep()

