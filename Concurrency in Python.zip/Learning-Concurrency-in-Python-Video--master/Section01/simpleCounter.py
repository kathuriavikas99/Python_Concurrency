# This is an example of a single-threaded program
# we simply print out the numbers 0-9
print("Single Threaded Counter")
for i in range(10):
  print("The Current Counter is {}".format(i))
  print("-------------------------")
