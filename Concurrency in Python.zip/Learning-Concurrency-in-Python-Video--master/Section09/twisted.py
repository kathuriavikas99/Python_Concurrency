import twisted

def main():
  print(twisted.__version__)

if __name__ == '__main__':
  main()